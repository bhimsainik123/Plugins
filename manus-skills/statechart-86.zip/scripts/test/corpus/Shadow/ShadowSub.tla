---- MODULE ShadowSub ----
CONSTANT c
====
